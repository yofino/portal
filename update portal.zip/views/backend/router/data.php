<?php $this->view('messages') ?>
<div class="row">
    <div class="col-lg-6">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold"><?= $title; ?></h6>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="card-body">
                        <?php echo form_open_multipart('router/edit') ?>
                        <div class="form-group">
                            <input type="hidden" name="id" value="<?= $router['id'] ?>">
                            <label for="name">IP Address</label>
                            <input type="text" id="name" name="ip_address" class="form-control" value="<?= $router['ip_address'] ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="email">Username</label>
                            <input type="text" id="email" name="username" class="form-control" value="<?= $router['username'] ?>">
                        </div>
                        <div class="form-group">
                            <label for="password">Password</label>
                            <input type="password" id="password" name="password" class="form-control" value="<?= $router['password'] ?>">
                        </div>
                        <div class="form-group">
                            <label for="port">Port</label>
                            <input type="number" id="port" name="port" class="form-control" value="<?= $router['port'] ?>">
                        </div>
                        <div class="modal-footer">
                            <button type="reset" class="btn btn-secondary" data-dismiss="modal">Reset</button>
                            <button type="submit" class="btn btn-primary">Simpan</button>
                        </div>
                    </div>
                </div>


                <?php echo form_close() ?>
            </div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold"></h6>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="card-body">

                    </div>
                </div>


                <?php echo form_close() ?>
            </div>
        </div>
    </div>
</div>