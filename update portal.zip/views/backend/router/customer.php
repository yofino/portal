<!-- bootstrap datepicker -->
<link rel="stylesheet" href="<?= base_url('assets/backend') ?>/bootstrap-datepicker/css/bootstrap-datepicker.min.css">

<!-- Page Heading -->

<?php $this->view('messages') ?>

</div>

<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold">Data <?= $title; ?></h6>

    </div>
    <div class="card-body">
        <div class="table-responsive">
            <form method="post" action="" id="submit-cetak">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr style="text-align: center">
                            <th style="text-align: center; width:20px">No</th>
                            <th>No Layanan</th>
                            <th>Nama </th>
                            <th>Mode User</th>
                            <th>Username</th>
                            <th style="text-align: center; width:50px">Aksi</th>

                        </tr>
                    </thead>

                    <tbody>
                        <?php $no = 1;
                        foreach ($customer as $r => $data) { ?>
                            <tr>
                                <td style="text-align: center"><?= $no++ ?>.</td>
                                <td><a href="<?= site_url('router/client/' . $data->no_services) ?>" class="badge badge-success"><?= $data->no_services; ?></a> <br>
                                <td><?= $data->name; ?></td>
                                <td><?= $data->mode_user ?></td>
                                <td><?= $data->user_mikrotik ?></td>
                                </td>
                                <td style="text-align: center"><a href="#" data-toggle="modal" data-target="#edit<?= $data->customer_id ?>" title="Edit"><i class="fa fa-edit" style="font-size:25px"></i></a>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </form>
        </div>
    </div>
</div>
</div>




<!-- Modal Edit -->
<?php foreach ($customer as $r => $data) { ?>
    <div class="modal fade" id="edit<?= $data->customer_id ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Edit Sinkronisai Mikrotik</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?= site_url('router/editcustomer') ?>" method="POST">
                        <div class="form-group">
                            <label for="nominal">No Layanan</label>

                            <input type="hidden" id="customer_id" name="customer_id" value="<?= $data->customer_id ?>" class="form-control" required>
                            <input type="text" id="no_services" name="no_services" value="<?= $data->no_services ?>" class="form-control" readonly>

                        </div>
                        <div class="form-group">
                            <label for="name">Nama</label>
                            <input type="text" id="name" name="name" value="<?= $data->name ?>" class="form-control" readonly>

                        </div>
                        <div class="form-group">
                            <label for="mode_user">Mode User</label>
                            <select name="mode_user" id="mode_user" class="form-control" required>
                                <?php if ($data->mode_user != null) { ?>
                                    <option value="<?= $data->mode_user; ?>"><?= $data->mode_user; ?></option>
                                <?php } ?>
                                <?php if ($data->mode_user == null) { ?>
                                    <option value="">-Pilih-</option>
                                <?php } ?>
                                <option value="PPPOE">PPPOE</option>
                                <option value="Hotspot">Hotspot</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="user_mikrotik">User Mikrotik</label>
                            <input type="text" id="user_mikrotik" name="user_mikrotik" value="<?= $data->user_mikrotik ?>" class="form-control">

                        </div>


                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </div>
                </form>
            </div>
        </div>
    </div>
<?php } ?>

<!-- bootstrap datepicker -->
<script src="<?= base_url('assets/backend') ?>/bootstrap-datepicker/js/bootstrap-datepicker.min.js"></script>
<script>
    //Date picker
    $('#tanggal').datepicker({
        format: 'yyyy-mm-dd',
        autoclose: true,
        todayHighlight: true,
    })
    $('#tanggal2').datepicker({
        format: 'yyyy-mm-dd',
        autoclose: true,
        todayHighlight: true,
    })
    $('#datepicker').datepicker({
        format: 'yyyy-mm-dd',
        autoclose: true,
        todayHighlight: true,
    })
    $('#btn-del-selected').click(function() {
        $('#submit-cetak').attr('action', '<?php echo base_url('customer/delselected') ?>');
        var confirm = window.confirm("Apakah Anda yakin ingin hapus pemasukan yang terpilih ?");
        if (confirm)
            $("#submit-cetak").submit();
    });
</script>