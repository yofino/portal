<div class="col-lg-12">
    <div class="card shadow mb-2">

        <div class="row">
            <div class="col-lg-12">
                <div class="card shadow mb-2">
                    <div class="card-header ">
                        <h6 class="m-0 font-weight-bold"><i class="fa fa-info-circle" style="font-size: 24px"> About Us</i></h6>
                    </div>
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="card-body">
                                <img src="<?= base_url('assets/images/1112-project.jpg') ?>" style=" display: block;margin-left: auto;margin-right: auto;width: 100%;" alt="">
                            </div>
                            <div class="container">
                                No. Telp / WA / Telegram : <a href="https://api.whatsapp.com/send?phone=<?= indo_tlp(6285283935826) ?>&text=Hallo, My-Wifi" target="blank">(+62)852-8393-5826</i></a>
                                <br>
                                Email : 11dubelasproject@gmail.com
                                <br>
                                Instagram : <a href=" https://www.instagram.com/1112.project/">1112.project </a> <br>
                                Website : <a href="https://1112-project.com/" target="blank" style="text-decoration: none;">www.1112-project.com</a>
                                <div class="row mt-1 mb-1 ml-2">
                                    <script src="https://apis.google.com/js/platform.js" gapi_processed="true"></script>
                                    <div id="___ytsubscribe_0" style="text-indent: 0px; margin: 0px; padding: 0px; background: transparent; border-style: none; float: none; line-height: normal; font-size: 1px; vertical-align: baseline; display: inline-block; width: 169px; height: 48px;"><iframe ng-non-bindable="" frameborder="0" hspace="0" marginheight="0" marginwidth="0" scrolling="no" style="position: static; top: 0px; width: 169px; margin: 0px; border-style: none; left: 0px; visibility: visible; height: 48px;" tabindex="0" vspace="0" width="100%" id="I0_1591374118028" name="I0_1591374118028" src="https://www.youtube.com/subscribe_embed?usegapi=1&amp;channelid=UCdszTqfUaxHDIrcn0YQnXNA&amp;layout=full&amp;count=default&amp;origin=https%3A%2F%2Fbillwifi.com&amp;gsrc=3p&amp;ic=1&amp;jsh=m%3B%2F_%2Fscs%2Fapps-static%2F_%2Fjs%2Fk%3Doz.gapi.id.9r5WlWXfDAM.O%2Fam%3DwQE%2Fd%3D1%2Fct%3Dzgms%2Frs%3DAGLTcCPMgYrADsPWYiIfT6-NpQi3u8Wdog%2Fm%3D__features__#_methods=onPlusOne%2C_ready%2C_close%2C_open%2C_resizeMe%2C_renderstart%2Concircled%2Cdrefresh%2Cerefresh%2Conload&amp;id=I0_1591374118028&amp;_gfid=I0_1591374118028&amp;parent=https%3A%2F%2Fbillwifi.com&amp;pfname=&amp;rpctoken=46059152" data-gapiattached="true"></iframe></div>
                                </div>
                            </div>
                            <div class="container">
                                Bagi yang ingin donasi silahkan ke rekening atau dompet digital berikut. <br>
                                <div class="row mt-2">

                                    <div class="col-4 d-none d-md-block">
                                        <img src="<?= base_url('assets/images/bri.png') ?>" alt="" style="width: 100px"> <br>
                                    </div>
                                    <div class="col-8">
                                        <h5 class="mt-3">BRI : 417901019831536</h5>
                                        <h5>A/N : Gingin Abdul Goni</h5>
                                    </div>

                                    <div class="col-8 mt-2">
                                        <h5 class="mt-3">OVO / LINKAJA 082337481227</h5>
                                        <h5>A/N : Gingin Abdul Goni</h5>
                                    </div>
                                    <div class="col-8 mt-2">
                                        <h5 class="mt-3">DANA 082337481227</h5>
                                        <h5>A/N : Rosita Wulandari</h5>
                                    </div>
                                    <div class="col-8 mt-2">
                                        <h5 class="mt-3">Paypal</h5>
                                        <h5>ginginabdulgoni@gmail.com</h5>
                                    </div>
                                </div>
                            </div>
                            <br>
                        </div>
                        <div class="col-lg-6">
                            <div class="card-body">
                                <img src="<?= base_url('assets/images/we.jpg') ?>" style=" display: block;margin-left: auto;margin-right: auto;width: 100%;" alt="">
                            </div>
                            <div class="container">
                                <div class="row" style="text-align: center">
                                    <div class="col-lg-5">
                                        <h6>Gingin Abdul Goni</h6>
                                    </div>
                                    <div class="col-lg-7">
                                        <h6>Rosita Wulandari, S.Kom., MTA</h6>
                                    </div>
                                </div>
                                <br>
                                <h3 style="text-align: center">Terima Kasih</h3>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="card shadow mb-2">
                    <div class="card-header">
                        <h6 class="font-weight-bold m-0"><i class="fa fa-info-circle" style="font-size:24px">About My-Wifi </i></h6><span>Terima kasih untuk semua yang telah mendukung pengembangan aplikasi ini</span>
                    </div>
                    <div class="row">

                        <div class="col-lg-12">
                            <div class="card-body">

                                </button>Aplikasi ini dipersembahkan untuk pengusaha internet, ISP ataupun RTRW Net, Semoga dengan adanya aplikasi ini membuat usahanya semakin sukses, dan membuat interaksi dengan pelanggan menjadi lebih mudah.<br>
                                <br>
                                <h3>ChangeLog</h3>
                                <div class="row">
                                    <div class="card col-12 col-sm-12 col-md-4 col-lg-4 mb-1 " style="width: 18rem;">
                                        <div class="embed-responsive embed-responsive-16by9">

                                            <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/i8GwH31yF5o?rel=0" allowfullscreen></iframe>
                                        </div>
                                        <div class="card-body text-center">
                                            <a href="#" data-toggle="modal" data-target="#v17" class="btn btn-primary">V1.7</a>
                                        </div>
                                        <!-- Modal -->
                                        <div class="modal fade" id="v17" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog modal-lg" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">ChaneLog V1.7</h5>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <h3 class="mt-3">ChangeLog My-Wifi V1.7</h3><span>Update 15 September 2021</span>
                                                        <div class="row">
                                                            <div class="col-sm-12 col-lg-6 col-md-6">
                                                                <h2>Administrator</h2>
                                                                <h5>1. Tagihan</h5>
                                                                <div class="container">
                                                                    <li>Hapus Tagihan Selected</li>
                                                                    <li>Bayar Tagihan Selected</li>
                                                                    <li>Invoice Small</li>
                                                                    <li>Simpan Tagihan Selected di menu Tagihan Bulan Ini</li>
                                                                    <li>Percepat Loading</li>
                                                                </div>
                                                                <h5>2. Pelanggan</h5>
                                                                <div class="container">
                                                                    <li>Tiket Gangguan</li>
                                                                    <li>Timeline Tiket</li>

                                                                </div>
                                                                <h5>3. Pengguna</h5>
                                                                <div class="container">
                                                                    <li>Multilevel Login (Administrator, Pelanggan, Operator, Teknisi)</li>
                                                                    <li>Ganti email, ktp pelanggan</li>

                                                                </div>
                                                                <h5>4. Schedule</h5>
                                                                <div class="container">
                                                                    <li>Schedule tagihan otomatis</li>
                                                                    <li>Schedule backup otomatis ke telegram</li>

                                                                </div>
                                                                <h5>5. Keuangan</h5>
                                                                <div class="container">
                                                                    <li>Kategori keuangan (Pemasukan & Pengeluaran)</li>
                                                                    <li>Hapus Selected</li>
                                                                    <li>Deteksi tagihan yang duplikat / sama</li>
                                                                    <li>Rekapitulasi / Filter Pemasukan by Operator atau Admin</li>

                                                                </div>

                                                            </div>
                                                            <div class="col-sm-12 col-lg-6 col-md-6">
                                                                <h5>6. Role Management</h5>
                                                                <div class="container">
                                                                    <li>Membatasi akses untuk operator dan pelanggan</li>

                                                                </div>
                                                                <h5>7. Pengaturan & Lainnya</h5>
                                                                <div class="container">
                                                                    <li>Menambahkan fitur Timezone indonesia (WIT, WITA, WIB)</li>
                                                                    <li>Full Custom Text WA</li>
                                                                    <li>ID Group Telegram Teknisi</li>
                                                                </div>
                                                                <h5>Info Tambahan</h5>
                                                                <div class="container">
                                                                    <li>Aplikasi ini mohon untuk tidak diperjual belikan kembali, dengan mengambil keuntungan secara pribadi ataupun kelompok, tanpa sepengetahuan 1112 Project</li>
                                                                    <li>Membeli atau donasi untuk aplikasi ini artinya menyepakati syarat dan ketentuan yang diberikan</li>
                                                                    <li> <span style="color:red">Kami sangat berterimakasih kepada para donatur yang mau memberikan total kode unik tiap bulannya kepada kami, untuk pengembangan aplikasi ini dan insyaalloh kami teruskan donasi kepada yg lebih membutuhkan.
                                                                        </span> </li>
                                                                    <li style="font-weight:700">Thanks for your busines</li>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card col-12 col-sm-12 col-md-4 col-lg-4 mb-1 " style="width: 18rem;">
                                        <div class="embed-responsive embed-responsive-16by9">

                                            <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/cf2R9N72EvE?rel=0" allowfullscreen></iframe>
                                        </div>
                                        <div class="card-body text-center">
                                            <a href="#" data-toggle="modal" data-target="#v16" class="btn btn-primary">V1.6</a>
                                        </div>
                                        <!-- Modal -->
                                        <div class="modal fade" id="v16" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog modal-lg" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">ChaneLog V1.6</h5>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <h3 class="mt-3">ChangeLog My-Wifi V1.6</h3><span>Update 14 April 2021</span>
                                                        <div class="row">
                                                            <div class="col-sm-12 col-lg-6 col-md-6">
                                                                <h2>Administrator</h2>
                                                                <h5>1. Tagihan</h5>
                                                                <div class="container">
                                                                    <li>Membuat fitur PPN 10% untuk pelanggan tertentu</li>
                                                                    <li>Menaampilkan siapa yang menerima pembayaran di Invoice atau Struk</li>
                                                                </div>
                                                                <h5>2. Pelanggan</h5>
                                                                <div class="container">
                                                                    <li>Custom No Layanan di tambah pelanggan (Bisa Juga Otomatis)</li>
                                                                    <li>Membuat fitur PPN 10% untuk pelanggan tertentu</li>
                                                                    <li>Menambahkan fitur jatuh tempo untuk pelanggan tertentu</li>
                                                                    <li>Menambahkan pilihan paket untuk pelanggan baru</li>
                                                                    <li>Menambahkan pilihan Coverage Area untuk pelanggan baru / lama</li>
                                                                </div>
                                                                <h5>3. Coverage Area</h5>
                                                                <div class="container">
                                                                    <li>Menambahkan fitur coverage Area untuk pengelompokan pelanggan</li>
                                                                    <li>Otomatis relasi Provinsi, kabupaten, kecamatan, kelurahan</li>

                                                                </div>
                                                                <h5>4. Register</h5>
                                                                <div class="container">
                                                                    <li>Menambahkan pilihan paket untuk pelanggan baru</li>
                                                                    <li>Menghilangkan fitur upload KTP (Penjelasan di Video)</li>
                                                                    <li>Menambahkan fitur centang Syarat & Ketentuan dan Kebijakan Privasi </li>
                                                                    <li>Setelah klik Daftar otomatis masuk notif ke Telegram Owner</li>
                                                                </div>

                                                            </div>
                                                            <div class="col-sm-12 col-lg-6 col-md-6">
                                                                <h5>5. Slideshow</h5>
                                                                <div class="container">
                                                                    <li>Menambahkan fitur Slide untuk media promosi atau bannner dihalaman depan</li>

                                                                </div>
                                                                <h5>6. Pengaturan</h5>
                                                                <div class="container">
                                                                    <li>Menambahkan fitur Syarat & Ketentuan dan Kebijakan Privasi</li>
                                                                    <li>Enable disable code Unique, custom text code unique</li>
                                                                    <li>Menambahkan Bot Telegran untuk meneria notif pendaftran dan konfirmasi dari pelanggan</li>
                                                                </div>
                                                                <h5>Info Tambahan</h5>
                                                                <div class="container">
                                                                    <li>Aplikasi ini mohon untuk tidak diperjual belikan kembali, dengan mengambil keuntungan secara pribadi ataupun kelompok, tanpa sepengetahuan 1112 Project</li>
                                                                    <li>Membeli atau donasi untuk aplikasi ini artinya menyepakati syarat dan ketentuan yang diberikan</li>
                                                                    <li> <span style="color:red">Kami sangat berterimakasih kepada para donatur yang mau memberikan total kode unik tiap bulannya kepada kami, untuk pengembangan aplikasi ini dan insyaalloh kami teruskan donasi kepada yg lebih membutuhkan.
                                                                        </span> </li>
                                                                    <li style="font-weight:700">Thanks for your busines</li>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card col-12 col-sm-12 col-md-4 col-lg-4 mb-1 " style="width: 18rem;">
                                        <div class="embed-responsive embed-responsive-16by9">
                                            <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/LOrzoOIXdlE?rel=0" allowfullscreen></iframe>
                                        </div>
                                        <div class="card-body text-center">
                                            <a href="#" data-toggle="modal" data-target="#v15" class="btn btn-primary">V1.5</a>
                                        </div>
                                        <!-- Modal -->
                                        <div class="modal fade" id="v15" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog modal-lg" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">ChaneLog V1.5</h5>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <h3 class="mt-3">ChangeLog My-Wifi V1.5</h3><span>Update 25 Desember 2020</span>
                                                        <div class="row">
                                                            <div class="col-sm-12 col-lg-6 col-md-6">
                                                                <h2>Administrator</h2>
                                                                <div class="container">

                                                                    <li>Membuat menu navbar bottom untuk tampilan di mobile</li>
                                                                </div>
                                                                <h5>1. Tagihan</h5>
                                                                <div class="container">
                                                                    <li>Membuat tombol bayar di kolom aksi dengan respon untuk pilihan cetak</li>
                                                                    <li>Menambahkan fitur Generate Tagihan (Pilih target bulan dan tahun)</li>
                                                                </div>
                                                                <h5>2. Pelanggan</h5>
                                                                <div class="container">
                                                                    <li>Menambahkan fitus status pelanggan (Aktif, Non-Aktif, Menunggu)</li>
                                                                    <li>Update Fitur Register otomatis tambah pelanggan (Menunggu) dan otomatis pembuatan akun pengguna</li>
                                                                    <li>Menampilkan Estimasi pendapatan setiap bulan di menu pelanggan Aktif</li>
                                                                </div>
                                                            </div>
                                                            <div class="col-sm-12 col-lg-6 col-md-6">
                                                                <h2>Pelanggan</h2>
                                                                <div class="container">
                                                                    <li>Menambahkan fitur konfirmasi pembayaran</li>
                                                                    <li>Setelah kirim bukti pembayaran bisa langsung kirim WA ke Admin</li>
                                                                </div>
                                                                <br>
                                                                <h5>Info Tambahan</h5>
                                                                <div class="container">
                                                                    <li>Aplikasi ini mohon untuk tidak diperjual belikan kembali, dengan mengambil keuntungan secara pribadi ataupun kelompok, tanpa sepengetahuan 1112 Project</li>
                                                                    <li>Membeli atau donasi untuk aplikasi ini artinya menyepakati syarat dan ketentuan yang diberikan</li>
                                                                    <li> <span style="color:red">Kami sangat berterimakasih kepada para donatur yang mau memberikan total kode unik tiap bulannya kepada kami, untuk pengembangan aplikasi ini dan insyaalloh kami teruskan donasi kepada yg lebih membutuhkan.
                                                                        </span> </li>
                                                                    <li style="font-weight:700">Thanks for your busines</li>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card col-12 col-sm-12 col-md-4 col-lg-4 mb-1 " style="width: 18rem;">
                                        <div class="embed-responsive embed-responsive-16by9">
                                            <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/OYOK2qe3Qnc?rel=0" allowfullscreen></iframe>
                                        </div>
                                        <div class="card-body text-center">
                                            <a href="#" data-toggle="modal" data-target="#v14" class="btn btn-primary">V1.4</a>
                                        </div>
                                        <!-- Modal -->
                                        <div class="modal fade" id="v14" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog modal-lg" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">ChaneLog V1.4</h5>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <h3 class="mt-3">ChangeLog My-Wifi V1.4</h3><span>Update 01 Oktober 2020</span>
                                                        <div class="row">
                                                            <div class="col-sm-12 col-lg-6 col-md-6">
                                                                <h2>Administrator</h2>
                                                                <h5>1. Tagihan</h5>
                                                                <div class="container">
                                                                    <li>Menampilkan Qr-Code di invoce a4</li>
                                                                    <li>Menampilkan tombol whatsapp (ucapan terimakasih) di kolom Aksi</li>
                                                                    <li>Menambahkan fitur tagihan bulan ini, dan simpan semua (Generate)</li>
                                                                </div>
                                                                <h5>2. Pengaturan</h5>
                                                                <div class="container">
                                                                    <li>Menambahkan pengaturan email untuk kirim verifikasi & lupa password</li>
                                                                    <li>Menambahkan pengaturan lainnya, untuk text whatsapp</li>
                                                                </div>
                                                            </div>
                                                            <div class="col-sm-12 col-lg-6 col-md-6">
                                                                <h2>Pelanggan</h2>
                                                                <div class="container">
                                                                    <li>Menampilkan detail paket dan tagihan jika di klik</li>
                                                                    <li>Menampilkan Invoice dan info Bayar</li>
                                                                </div>
                                                                <br>
                                                                <h5>Info Tambahan</h5>
                                                                <div class="container">
                                                                    <li>Aplikasi ini mohon untuk tidak diperjual belikan kembali, dengan mengambil keuntungan secara pribadi ataupun kelompok, tanpa sepengetahuan 1112 Project</li>
                                                                    <li>Membeli atau donasi untuk aplikasi ini artinya menyepakati syarat dan ketentuan yang diberikan</li>
                                                                    <li> <span style="color:red">Kami sangat berterimakasih kepada para donatur yang mau memberikan total kode unik tiap bulannya kepada kami, untuk pengembangan aplikasi ini dan insyaalloh kami teruskan donasi kepada yg lebih membutuhkan.
                                                                        </span> </li>
                                                                    <li style="font-weight:700">Thanks for your busines</li>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card col-12 col-sm-12 col-md-4 col-lg-4 mb-1 " style="width: 18rem;">
                                        <div class="embed-responsive embed-responsive-16by9">
                                            <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/vq0SdkOkh7E?rel=0" allowfullscreen></iframe>
                                        </div>
                                        <div class="card-body text-center">
                                            <a href="#" data-toggle="modal" data-target="#v13" class="btn btn-primary">V1.3</a>
                                        </div>
                                        <!-- Modal -->
                                        <div class="modal fade" id="v13" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog modal-lg" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">ChaneLog V1.3</h5>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <h3 class="mt-3">ChangeLog My-Wifi V1.3</h3><span>Update 15 Agustus 2020</span>
                                                        <div class="row">
                                                            <div class="col-sm-12 col-lg-6 col-md-6">
                                                                <h2>Administrator</h2>
                                                                <h5>1. Tagihan</h5>
                                                                <div class="container">
                                                                    <li>Menampilkan semua akun bank dan nama domain di Notifikasi Whatsapp</li>
                                                                    <li>Menampilkan periode tagihan ketika kirim ucapan terimakasih</li>
                                                                    <li>Menambahkan fitur filter tagihan setiap bulannya di menu Semua Tagihan</li>
                                                                </div>
                                                                <h5>2. Keuangan</h5>
                                                                <div class="container">
                                                                    <li>Menonaktifkan dulu menu Laporan keuangan, karena masih ada bugs utk pengguna My-Wifi dari V1.0 - V1.1, Alternatif gunakan laporan dari data pemasukan dan data pengeluaran</li>
                                                                </div>
                                                                <h5>3. Pengguna / Multilevel</h5>
                                                                <div class="container">
                                                                    <li>Tambah, edit, hapus pengguna</li>
                                                                </div>
                                                                <h5>4. Backup Database</h5>
                                                                <div class="container">
                                                                    <li>Backup database, download zip</li>
                                                                </div>
                                                            </div>
                                                            <div class="col-sm-12 col-lg-6 col-md-6">
                                                                <h2>Pelanggan</h2>
                                                                <h5>1. Dashboard</h5>
                                                                <div class="container">
                                                                    <li>Menampilkan Item Layanan</li>
                                                                    <li>Menampilkan status tagihan bulan ini</li>
                                                                </div>
                                                                <h5>2. Status Langganan</h5>
                                                                <div class="container">
                                                                    <li>Menampilkan detail layanan aktif pelanggan</li>
                                                                </div>
                                                                <h5>3. Riwayat Tagihan</h5>
                                                                <div class="container">
                                                                    <li>Menampilkan semua riwayat tagihan yang sudah bayar ataupun belum bayar
                                                                </div>
                                                                <h5>4. Pengaturan</h5>
                                                                <div class="container">
                                                                    <li>Edit Profile atau Akun</li>
                                                                    <li>Ganti Password</li>

                                                                </div>
                                                                <h5>5. Info Tambahan</h5>
                                                                <div class="container">
                                                                    <li>Aplikasi ini mohon untuk tidak diperjual belikan kembali, dengan mengambil keuntungan secara pribadi ataupun kelompok, tanpa sepengetahuan 1112 Project</li>
                                                                    <li>Membeli atau donasi untuk aplikasi ini artinya menyepakati syarat dan ketentuan yang diberikan</li>
                                                                    <li> <span style="color:red">Kami sangat berterimakasih kepada para donatur yang mau memberikan total kode unik tiap bulannya kepada kami, untuk pengembangan aplikasi ini dan insyaalloh kami teruskan donasi kepada yg lebih membutuhkan.
                                                                        </span> </li>
                                                                    <li style="font-weight:700">Thanks for your busines</li>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card col-12 col-sm-12 col-md-4 col-lg-4 mb-1 " style="width: 18rem;">
                                        <div class="embed-responsive embed-responsive-16by9">
                                            <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/840ViOfMVbk?rel=0" allowfullscreen></iframe>
                                        </div>
                                        <div class="card-body text-center">
                                            <a href="#" data-toggle="modal" data-target="#v12" class="btn btn-primary">V1.2</a>
                                        </div>
                                        <!-- Modal -->
                                        <div class="modal fade" id="v12" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog modal-lg" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">ChaneLog V1.2</h5>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <h3 class="mt-3">ChangeLog My-Wifi V1.2</h3><span>Update 21 Juli 2020</span>
                                                        <div class="row">
                                                            <div class="col-sm-12 col-lg-6 col-md-6">
                                                                <h5>1. Landing Page / Halaman Depan</h5>
                                                                <div class="container">
                                                                    <li>Menambahkan Tombol Whatsapp</li>
                                                                    <li>Menambahkan Menu Produk / Layanan dan order ke WA</li>
                                                                    <li>Menambahkan Menu About Us</li>
                                                                </div>
                                                                <h5>2. Keuangan</h5>
                                                                <div class="container">
                                                                    <li>Memperbaiki plugin Kalender di menu form tanggal tambah pemasukan</li>
                                                                    <li>Memperbaiki plugin Kalender di menu form tanggal tambah pengeluaran</li>
                                                                    <li>Menambahkan fitur export pdf, excel, copy, csv, print dan Column Visibility (Menghilangkan Kolom)</li>
                                                                </div>
                                                                <h5>3. Produk Layanan</h5>
                                                                <div class="container">
                                                                    <li>Tambah, edit, hapus produk layanan</li>
                                                                    <li>Menambahkan plugin Upload Management</li>
                                                                </div>
                                                            </div>
                                                            <div class="col-sm-12 col-lg-6 col-md-6">
                                                                <h5>4. Tagihan</h5>
                                                                <div class="container">
                                                                    <li>Menampilkan rincian paket dalam invoice</li>
                                                                    <li>Memisahkan menu tagihan yang belum bayar dan sudah bayar</li>
                                                                    <li>Menambahkan fitur cetak invoice dengan pilihan ukuran kertas A4 dan Thermal</li>
                                                                    <li>Menambahkan fitur export pdf, excel, copy, csv, print </li>
                                                                </div>

                                                                <h5>5. Info Tambahan</h5>
                                                                <div class="container">
                                                                    <li>Aplikasi ini mohon untuk tidak diperjual belikan kembali, dengan mengambil keuntungan secara pribadi ataupun kelompok, tanpa sepengetahuan 1112 Project</li>
                                                                    <li>Membeli atau donasi untuk aplikasi ini artinya menyepakati syarat dan ketentuan yang diberikan</li>
                                                                    <li> <span style="color:red">Kami sangat berterimakasih kepada para donatur yang mau memberikan total kode unik tiap bulannya kepada kami, untuk pengembangan aplikasi ini dan insyaalloh kami teruskan donasi kepada yg lebih membutuhkan.
                                                                        </span> </li>
                                                                    <li style="font-weight:700">Thanks for your busines</li>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card col-12 col-sm-12 col-md-4 col-lg-4 mb-1 " style="width: 18rem;">
                                        <div class="embed-responsive embed-responsive-16by9">
                                            <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/zW1VnyztKos?rel=0" allowfullscreen></iframe>
                                        </div>
                                        <div class="card-body text-center">
                                            <a href="#" data-toggle="modal" data-target="#v11" class="btn btn-primary">V1.1</a>
                                        </div>
                                        <!-- Modal -->
                                        <div class="modal fade" id="v11" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog modal-lg" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">ChaneLog V1.1</h5>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <h3 class="mt-3">ChangeLog My-Wifi V1.1</h3><span>Update 04 Juni 2020</span>
                                                        <div class="row">
                                                            <div class="col-sm-12 col-lg-6 col-md-6">
                                                                <h5>1. Tagihan</h5>
                                                                <div class="container">
                                                                    <li>Menambahkan kode unik ketika tambah / cetak invoice</li>
                                                                    <li>Cetak Invoice Individu</li>
                                                                    <li>Cetak Berdasarkan yang dipilih</li>
                                                                    <li>Cetak Semua yang belum bayar</li>
                                                                    <li>Cetak Semua yang sudah bayar</li>
                                                                    <li>Auto Print Preview ketika klik tombol <button class="btn btn-primary btn-sm"><i class="fa fa-print"> Print</i></button> sehingga lebih cepat untuk eksekusi cetak tanpa harus download dulu ke pdf</li><br>
                                                                </div>
                                                                <h5>2. Keuangan</h5>
                                                                <div class="container">
                                                                    <li>Memperbaiki error menu Expenditure ketika di upload ke hosting</li>
                                                                    <li>Fitur Laporan Keuangan untuk melihat debit kredit secara realtime</li>
                                                                    <li>Cetak Laporan Keuangan</li>
                                                                    <li>Cetak Laporan Keuangan berdasarkan filter tanggal</li>
                                                                    <li>Auto Print Preview ketika klik tombol <button class="btn btn-primary btn-sm"><i class="fa fa-print"> Print</i></button> sehingga lebih cepat untuk eksekusi cetak tanpa harus download dulu ke pdf</li>
                                                                </div>
                                                            </div>
                                                            <div class="col-sm-12 col-lg-6 col-md-6">
                                                                <h5>3. Pengaturan</h5>
                                                                <div class="container">
                                                                    <li>Memperbaiki tampilan icon WA yang tidak tampil di hosting</li>
                                                                    <li>Menambahkan fitur jatuh tempo pembayaran</li>
                                                                    <li>Menambahkan fitur data rekening bank / dompet digital untuk ditampilkan di invoice</li>
                                                                </div><br>
                                                                <h5>4. Info Tambahan</h5>
                                                                <li>Aplikasi ini mohon untuk tidak diperjual belikan kembali, dengan mengambil keuntungan secara pribadi ataupun kelompok, tanpa sepengetahuan 1112 Project</li>
                                                                <li>Membeli atau donasi untuk aplikasi ini artinya menyepakati syarat dan ketentuan yang diberikan</li>
                                                                <li> <span style="color:red">Kami sangat berterimakasih kepada para donatur yang mau memberikan total kode unik tiap bulannya kepada kami, untuk pengembangan aplikasi ini dan insyaalloh kami teruskan donasi kepada yg lebih membutuhkan.
                                                                    </span> </li>
                                                                <li style="font-weight:700">Thanks for your busines</li>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card col-12 col-sm-12 col-md-4 col-lg-4 mb-1 " style="width: 18rem;">
                                        <div class="embed-responsive embed-responsive-16by9">
                                            <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/gVUkQgSmxy0?rel=0" allowfullscreen></iframe>
                                        </div>
                                        <div class="card-body text-center">
                                            <a href="#" data-toggle="modal" data-target="#v10" class="btn btn-primary">V1.0</a>
                                        </div>
                                        <!-- Modal -->
                                        <div class="modal fade" id="v10" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog modal-lg" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">ChaneLog V1.0</h5>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <h3 class="mt-3">Fitur My-Wifi V1.0</h3><span>Update 20 April 2020</span>
                                                        <div class="row">
                                                            <div class="col-sm-12 col-lg-6 col-md-6">
                                                                <h5>1. Beranda</h5>
                                                                <div class="container">
                                                                    <li>Menampilkan data saldo (Total Pendapatan - Total Pengeluaran)</li>
                                                                    <li>Menampilkan data pendapatan bulan ini</li>
                                                                    <li>Menampilkan data Pengeluaran bulan ini</li>
                                                                    <li>Menampilkan data Iuran yang belum dibayar</li>
                                                                    <li>Menampilkan grafik pendapatan tahun ini untuk evaluasi</li>
                                                                    <li>Menampilkan tombol cepat ke fitur lain</li>
                                                                </div><br>
                                                                <h5>2. Pelanggan</h5>
                                                                <div class="container">
                                                                    <li>Tambah, Edit &amp; Hapus data pelanggan</li>
                                                                    <li>Otomatis membuat no layanan pelanggan</li>
                                                                    <li>Validasi agar tidak terjadi double input pada no layanan email, no ktp pelanggan</li>
                                                                    <li>Tambah layanan pelanggan dengan klik tombol <button class="btn btn-success" style="font-size:10px">Rincian Paket</button></li>
                                                                </div>
                                                                <h5>3. Layanan</h5>
                                                                <div class="container">
                                                                    <li>Tambah, edit, hapus category layanan</li>
                                                                    <li>Tambah, edit, hapus item layanan</li>
                                                                    <li>Validasi kertkaitan data category dan data item</li>
                                                                </div>
                                                            </div>
                                                            <div class="col-sm-12 col-lg-6 col-md-6">
                                                                <h5>4. Iuran / Tagihan</h5>
                                                                <div class="container">
                                                                    <li>Tambah data tagihan dengan mengambil data layanan dari database pelanggan</li>
                                                                    <li>Validasi data tagihan agar tidak terjadi double double input periode tagihan</li>
                                                                    <li>Validasi agar tidak terjadi double input pada no layanan email, no ktp pelanggan</li>
                                                                    <li>Mengirim notifikasi info tagihan ke no WA pelanggan</li>
                                                                    <li>Menampilkan status pembayaran tagihan, jika mau bayar tinggal klik tombol <i class="fa fa-eye" style="color:gray"></i></li>
                                                                    <li>Setelah bayar bisa kirim ucapan terima kasih ke no WA pelanggan</li>
                                                                </div><br>
                                                                <h5>5. Keuangan</h5>
                                                                <div class="container">
                                                                    <li>Auto input data pendapatan ketika ada tagihan yang sudah dibayarkan</li>
                                                                    <li>Tambah, edit, hapus data pendapatan</li>
                                                                    <li>Tambah, edit, hapus data pengeluaran</li>
                                                                </div><br>
                                                                <h5>6. Pengaturan</h5>
                                                                <div class="container">
                                                                    <li>Mengubah data perusahaan / Company Profile</li>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <br>* Jika masih ada yang kurang dipahami jangan sungkan untuk bertanya di WA atau di fitur live chat pada halaman ini yah,
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>

<!--Start of Tawk.to Script-->
<script type="text/javascript">
    var Tawk_API = Tawk_API || {},
        Tawk_LoadStart = new Date();
    (function() {
        var s1 = document.createElement("script"),
            s0 = document.getElementsByTagName("script")[0];
        s1.async = true;
        s1.src = 'https://embed.tawk.to/5d0519ec36eab9721117a07a/default';
        s1.charset = 'UTF-8';
        s1.setAttribute('crossorigin', '*');
        s0.parentNode.insertBefore(s1, s0);
    })();
</script>
<!--End of Tawk.to Script-->