<!-- Page Heading -->
<?php $role = $this->db->get_where('role_management', ['role_id' => $this->session->userdata('role_id')])->row_array() ?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">

    <?php
    $customerall = $this->db->get('customer')->result();
    foreach ($customerall as $result) {
        $row = array();
        $row = $result->email;
        $dataa[] = $row;
    }
    // echo json_encode($dataa);
    $count_values = array_count_values($dataa);
    function findDuplicates($count)
    {
        return $count > 1;
    }
    $duplicates = array_filter(array_count_values($dataa), "findDuplicates");
    foreach ($customerall as $result) {
        $row = array();
        $row = $result->no_services;
        $dataaa[] = $row;
    }
    $count_valuess = array_count_values($dataaa);
    function findDuplicatess($count)
    {
        return $count > 1;
    }
    $duplicatess = array_filter(array_count_values($dataaa), "findDuplicatess");
    // $noservices = json_encode($duplicatess);

    ?>
    <?php if (count($duplicates)  > 0) { ?>
        <div class="alert alert-danger alert-dismissible">
            <i class="icon fa fa-ban"></i> Ada Email Yang Sama
            <pre>
<?php
        $a = $duplicates;
        print_r($a);
?>
 
</pre>
        </div>
    <?php } ?>




    <?php if ($this->session->userdata('role_id') == 1 or $role['add_customer'] == 1) { ?>

        <a href="<?= site_url('customer/add') ?>" class="d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-plus fa-sm text-white-50"></i> Tambah</a>

    <?php } ?>
    <?php if (count($duplicates) == 0) { ?>
        <?php if (count($duplicatess) == 0) { ?>
            <?php if ($company['import'] == 1) { ?>
                <a href="<?= site_url('customer/import') ?>" class="d-sm-inline-block btn btn-sm btn-secondary shadow-sm"><i class="fas fa-file-excel fa-sm text-white-50"></i> Import</a>
            <?php } ?>
        <?php } ?>
    <?php } ?>
</div>
<?php if (count($duplicatess)  > 0) { ?>
    <div class="alert alert-danger alert-dismissible">
        <i class="icon fa fa-ban"></i> Ada No Layanan Yang Sama <br>
        <pre>
<?php
    $a = $duplicatess;
    print_r($a);
?>
 
</pre>
    </div>

<?php } ?>
<?php $this->view('messages') ?>
<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h6 class="m-0 font-weight-bold">Data Pelanggan</h6>
            <?php $query = "SELECT *
FROM `services` JOIN `customer`  ON `customer`.`no_services` = `services`.`no_services` WHERE  `customer`.`c_status` = 'Aktif' 
";
            $querying = $this->db->query($query)->result(); ?>
            <?php $grandtotal = 0;
            foreach ($querying as  $dataa)
                $grandtotal += (int) $dataa->total;
            ?>
            <?php if ($this->session->userdata('role_id') == 1) { ?>
                <?php if ($title == 'Aktif') { ?>
                    <h6>Estimasi Pendapatan <?= indo_currency($grandtotal); ?> / Bulan <br>Belum Termasuk PPN</h6>
                <?php } ?>
            <?php } ?>
        </div>
    </div>
    <div class="card-body">
        <?php if ($title == 'Customer') { ?>
            <a href="#" id="#filterbyModal" data-toggle="modal" data-target="#filterbyModal" class="d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-cube fa-sm text-white-50"></i> Filter by</a>
        <?php } ?>
        <div class="table-responsive mt-2">
            <table class="table table-bordered" id="example" width="100%" cellspacing="0">
                <thead>
                    <tr style="text-align: center">
                        <th style="text-align: center; width:20px">No</th>
                        <th>No Layanan</th>
                        <th>Nama</th>
                        <th>Email</th>
                        <th>No Telp.</th>
                        <th>Status</th>
                        <th>Ppn</th>
                        <?php if ($this->session->userdata('role_id') == 1) { ?>
                            <th style="width: 100px">Tagihan / Bulan</th>
                        <?php } ?>
                        <th>Alamat</th>
                        <th style="text-align: center">Aksi</th>
                    </tr>
                </thead>

                <tbody>



                </tbody>

            </table>
        </div>
    </div>
</div>
<div class="modal fade" id="filterbyModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Filter By</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <?php echo form_open_multipart('customer/filterby') ?>
                <div class="form-group">
                    <label for="status">Status Pelanggan</label>
                    <select name="status" id="status" class="form-control" required>
                        <option value="">-Pilih-</option>
                        <option value="Aktif">Aktif</option>
                        <option value="Non-Aktif">Non-Aktif</option>
                        <option value="Menunggu">Menunggu</option>

                    </select>
                </div>
                <div class="form-group">
                    <label for="coverage">Coverage Area</label>
                    <select name="coverage" id="coverage" class="form-control">
                        <option value="0">-Semua-</option>
                        <?php foreach ($coverage as $data) { ?>
                            <option value="<?= $data->coverage_id ?>"><?= $data->c_name ?></option>
                        <?php } ?>
                    </select>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">Filter</button>
                </div>
                <?php echo form_close() ?>
            </div>
        </div>
    </div>
</div>
<!-- Modal Hapus -->

<div class="modal fade" id="DeleteModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Hapus Pelanggan</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <?php echo form_open_multipart('customer/delete') ?>
                <input type="hidden" name="customer_id" id="customer_id" class="form-control">

                Apakah and yakin hapus pelanggan <span id="no_services"></span> <span id="name"></span> ?
                <br>

                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                    <button type="submit" id="click-me" class="btn btn-danger">Hapus</button>
                </div>
                <?php echo form_close() ?>
            </div>
        </div>
    </div>
</div>

<?php if ($title == 'Customer') { ?>

    <script>
        $(document).ready(function() {
            $('#example').DataTable({
                "processing": true,
                "serverSide": true,
                "paging": true,
                "lengthChange": true,
                "searching": true,
                "info": true,
                "autoWidth": true,
                "responsive": true,
                "order": [],
                "ajax": {
                    "url": "<?= base_url('customer/getAllCustomer'); ?>",
                    "type": "POST"
                },
                "columDefs": [{
                    "target": [-1],
                    "orderable": false,
                }]
            });
        });
    </script>
<?php } ?>
<?php if ($title == 'Aktif') { ?>

    <script>
        $(document).ready(function() {
            $('#example').DataTable({
                "processing": true,
                "serverSide": true,
                "paging": true,
                "lengthChange": true,
                "searching": true,
                "info": true,
                "autoWidth": true,
                "responsive": true,
                "order": [],
                "ajax": {
                    "url": "<?= base_url('customer/getActiveCustomer'); ?>",
                    "type": "POST"
                },
                "columDefs": [{
                    "target": [-1],
                    "orderable": false,
                }]
            });
        });
    </script>
<?php } ?>
<?php if ($title == 'Non-Aktif') { ?>

    <script>
        $(document).ready(function() {
            $('#example').DataTable({
                "processing": true,
                "serverSide": true,
                "paging": true,
                "lengthChange": true,
                "searching": true,
                "info": true,
                "autoWidth": true,
                "responsive": true,
                "order": [],
                "ajax": {
                    "url": "<?= base_url('customer/getNonActiveCustomer'); ?>",
                    "type": "POST"
                },
                "columDefs": [{
                    "target": [],
                    "orderable": false,
                }]
            });
        });
    </script>
<?php } ?>
<?php if ($title == 'Waiting') { ?>

    <script>
        $(document).ready(function() {
            $('#example').DataTable({
                "processing": true,
                "serverSide": true,
                "paging": true,
                "lengthChange": true,
                "searching": true,
                "info": true,
                "autoWidth": true,
                "responsive": true,
                "order": [],
                "ajax": {
                    "url": "<?= base_url('customer/getWaitCustomer'); ?>",
                    "type": "POST"
                },
                "columDefs": [{
                    "target": [],
                    "orderable": false,
                }]
            });
        });
    </script>
<?php } ?>

<script>
    $(document).on('click', '#delete', function() {

        $('#customer_id').val($(this).data('customer_id'))
        $('#no_services').html($(this).data('no_services'))
        $('#name').html($(this).data('name'))


    })
</script>
<script>
    $("#clickdelincome").click(function() {
        if ($(this).is(":checked")) {
            $("#delincome").val('1');
            $("#formdelincome").show();
        } else {
            $("#delincome").val('0');
            $("#formdelincome").hide();
            document.getElementById("clickdelincome").checked = false;
        }
    });
</script>