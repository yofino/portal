<?php //==============================START=========================================//
/*
     *  Base Code   : Gingin Abdul Goni | Rosita Wulandari, S.Kom,.MTA
     *  Email       : ginginabdulgoni@gmail.com
     *  Instagram   : @ginginabdulgoni
     *
     *  Name        : My-Wifi
     *  Function    : Manage Client and Billing
     *  Manufacture : April 2020 
     *  Last Edited : 25 Desember 2020 | V1.5 
     *
     *  Please do not change this code
     *  All damage caused by editing we will not be responsible please think carefully,
     *
     */
//==============================START CODE=========================================// 
?>
<?php $this->view('messages') ?>
<div class="col-lg-12">
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold">Kirim Pesan Whatsapp Web Gratis</h6>
        </div>
        <div class="row">
            <div class="col-lg-6">
                <div class="card-body">
                    <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" id="pills-customer-tab" data-toggle="pill" href="#pills-customer" role="tab" aria-controls="pills-customer" aria-selected="true">Pelanggan</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" id="pills-public-tab" data-toggle="pill" href="#pills-public" role="tab" aria-controls="pills-profile" aria-selected="false">Umum</a>
                        </li>
                    </ul>
                    <div class="tab-content" id="pills-tabContent">
                        <div class="tab-pane fade show active" id="pills-customer" role="tabpanel" aria-labelledby="pills-customer-tab">
                            <form action="">
                                <div class="form-group">
                                    <label for="name">No Tujuan</label>
                                    <select class="form-control select2" name="no_target" style="width: 100%;" required>
                                        <?php
                                        foreach ($customer as $r => $data) { ?>
                                            <option value="<?= indo_tlp($data->no_wa) ?>"><?= $data->no_wa ?> - <?= $data->name ?></option>
                                        <?php } ?>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label>Pesan</label>
                                    <textarea name="message" id="message" class="form-control"></textarea>
                                </div>
                                <div class="modal-footer">
                                    <button type="reset" class="btn btn-secondary" data-dismiss="modal">Reset</button>
                                    <a href="" class="btn btn-primary" id="btn-sendWA">Kirim</a>
                                </div>
                            </form>
                        </div>

                        <div class="tab-pane fade" id="pills-public" role="tabpanel" aria-labelledby="pills-public-tab">
                            <form action="">
                                <div class="form-group">
                                    <label for="name">No Tujuan</label>
                                    <input type="number" name="no_target2" id="no_target2" class="form-control">
                                </div>

                                <div class="form-group">
                                    <label>Pesan</label>
                                    <textarea name="message2" id="message2" class="form-control"></textarea>
                                </div>
                                <div class="modal-footer">
                                    <button type="reset" class="btn btn-secondary" data-dismiss="modal">Reset</button>
                                    <a href="" class="btn btn-primary" id="btn-sendWA2">Kirim</a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="card-body">
                    <h5>Keterangan</h5>
                    <li>Tambahkan tanda asterik (<code>*</code>) di antara text utuk menebalkan text <br>Contoh : <code>*text-tebal* </code></li>
                    <li>Tambahkan tanda underscore (<code>_</code>) di antara text utuk membuat text miring <br>Contoh : <code>_text-miring_</code> </li>
                    <li>Tambahkan tanda tilde (<code>~</code>) di antara text utuk membuat text dicoret <br>Contoh : <code>~text-coret~</code> </li>
                    <li>Tambahkan tanda (<code>%0A</code>) untuk membuat baris baru (Enter) </li>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $(function() {
        //Initialize Select2 Elements
        $('.select2').select2()
    });
</script>

<script>
    $("#btn-sendWA").click(function() {
        var no_target = $('[name="no_target"]');
        var message = $('[name="message"]');
        var cno_target = $('#no_target').val();
        var cmessage = $('#message').val();
        if (cno_target == '') {
            $('#no_target').focus()
            $('#btn-sendWA').attr('href', "#");

        } else if (cmessage == '') {
            $('#message').focus()
            $('#btn-sendWA').attr('href', "#");
        } else {
            $('#btn-sendWA').attr('target', "blank");
            $('#btn-sendWA').attr('href', "https://api.whatsapp.com/send?phone=" + no_target.val() + "&text=" + message.val());
            $("#btn-sendWA").submit();
        }
    });

    $("#btn-sendWA2").click(function() {
        var no_target2 = $('[name="no_target2"]');
        var message2 = $('[name="message2"]');
        var cno_target2 = $('#no_target2').val();
        var cmessage2 = $('#message2').val();
        if (cno_target2 == '') {
            $('#no_target2').focus()
            $('#btn-sendWA2').attr('href', "#");
        } else if (cmessage2 == '') {
            $('#message2').focus()
            $('#btn-sendWA2').attr('href', "#");
        } else {
            $('#btn-sendWA2').attr('target', "blank");
            $('#btn-sendWA2').attr('href', "https://api.whatsapp.com/send?phone=" + no_target2.val() + "&text=" + message2.val());
            $("#btn-sendWA2").submit();
        }
    });
</script>