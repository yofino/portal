<div class="col-lg-6">
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold"><?= $title ?></h6>
        </div>
        <div class="card-body">

            <div class="row">
                <div class="col-lg">
                    <?php $this->view('messages') ?>
                    <div class="box box-primary">
                        <div class="box-body box-profile">
                            <form action="<?= base_url('member/changepassword'); ?>" method="post">
                                <div class="form-group">
                                    <label for="current_password">Password Lama</label>
                                    <input type="password" class="form-control" id="current_password" name="current_password">
                                    <?= form_error('current_password', '<small class="text-danger pl-3 ">', '</small>') ?>
                                </div>
                                <div class="form-group">
                                    <label for="new_password1">Password Baru</label>
                                    <input type="password" class="form-control" id="new_password1" name="new_password1">
                                    <?= form_error('new_password1', '<small class="text-danger pl-3 ">', '</small>') ?>
                                </div>
                                <div class="form-group">
                                    <label for="new_password2">Konfirmasi Password</label>
                                    <input type="password" class="form-control" id="new_password2" name="new_password2">
                                    <?= form_error('new_password2', '<small class="text-danger pl-3 ">', '</small>') ?>
                                </div>
                                <div class="form-group">
                                    <button class="btn btn-primary">Change Password</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>