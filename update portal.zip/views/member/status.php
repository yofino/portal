<div class="row">
    <div class="col-md-6">
        <div class="card shadow mb-2">
            <div class="card-header py-1">
                <h6 class="m-0 font-weight-bold">Informasi Layanan</h6>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="">No Layanan</label>
                            <input type="" class="form-control" value="<?= $customer->no_services ?>" readonly>
                        </div>
                        <div class="form-group">
                            <label for="">Nama</label>
                            <input type="" class="form-control" value="<?= $customer->name ?>" readonly>
                        </div>
                        <div class="form-group">
                            <label for="">Email</label>
                            <input type="" class="form-control" value="<?= $customer->email ?>" readonly>
                        </div>
                        <div class="form-group">
                            <label for="">No KTP</label>
                            <input type="" class="form-control" value="<?= $customer->no_ktp ?>" readonly>
                        </div>
                        <div class="form-group">
                            <label for="">Alamat</label>
                            <textarea class="form-control" readonly><?= $customer->address ?></textarea>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card shadow mb-2">
            <div class="card-header py-1">
                <h6 class="m-0 font-weight-bold">Layanan Anda</h6>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="box box-widget">
                            <div class="box-body table-responsive">
                                <table class="table ">
                                    <thead>
                                        <tr style="text-align: center">
                                            <th>Item Layanan</th>
                                            <th>Kategori</th>
                                        </tr>
                                    </thead>
                                    <tbody id="dataTables">
                                        <?php $no = 1;
                                        foreach ($services as $c => $data) { ?>
                                            <tr style="text-align: center">
                                                <td><?= $data->item_name ?></td>
                                                <td><?= $data->category_name ?></td>
                                            </tr>
                                        <?php } ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>