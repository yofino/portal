<div class="container mt-2">
    <div class="card" style="min-height:280px">
        <div class="card-header text-center">
            Tentang Kami
        </div>
        <div class="card-body">
            <p class="card-text"><?= $company['description'] ?></p>
        </div>
    </div>
</div>