<div class="container">
    <div class="portfolio mb-3 mt-3">
        <?= $company['policy'] ?>
    </div>
</div>