<?php defined('BASEPATH') or exit('No direct script access allowed');

class Router_m extends CI_Model
{
    public function edit($post)
    {
        $params = [
            'ip_address' => $post['ip_address'],
            'username' => $post['username'],
            'password' => $post['password'],
            'port' => $post['port'],
        ];
        $this->db->where('id', $post['id']);
        $this->db->update('router', $params);
    }
    public function editcustomer($post)
    {
        $params = [
            'mode_user' => $post['mode_user'],
            'user_mikrotik' => $post['user_mikrotik'],

        ];
        $this->db->where('customer_id', $post['customer_id']);
        $this->db->update('customer', $params);
    }
}
